function [ D_weighted ] = DTW( t, r )
% clear all; close all; clc;

% t = [ 0 0.1 0.2 0.3 0.4 0.5 0.4 0.3 0.2 0.2 0.1 0 -0.1 -0.2 -0.3 -0.4 -0.5 -0.4 -0.3 -0.2 -0.1 0];
 t = [ 0.0 0.1 0.2 0.3 0.4 0.5 0.4 0.3 0.2 0.1 0.0]
%r = [1.578 0.000 -1.560 1.5 0 1.2]

% r = [ -0.2 -0.1 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0.2 0.3 0.4 0.5 0.4 0.3 0.2 0.2 0.1 0 -0.1 -0.2 -0.3 -0.4 -0.5 -0.4 -0.3 ];
r = [ 0.2 0.1 0 0 0 0 0 0.1 0.2 0.3 0.4 0.5 0.4 0.3  ]
%t = [1.578 1.278 0.000 -1.345 1.678 1.340 0.000 1.200 1.450 1.670 0.120 ];

figure(1);  %figure; stem(r, '-bo');
axis ([1 11 0 0.5]);
grid on 
stem(t, '-ro');
set(gca,'XTick',[1:1:11]);
set(gca,'XTickLabel',{'1','2','3','4','5', '6', '7','8', '9', '10', '11'}, 'FontSize', 16);
set(gca,'YTick',0:0.1:0.5);
set(gca,'YTickLabel',{'0.0', '0.1','0.2', '0.3','0.4', '0.5'}, 'FontSize', 16);
set(gcf, 'PaperPositionMode', 'auto')

figure(2);  
axis ([1 14 0 0.5]);
grid on 
stem(r, '-bo');
set(gca,'XTick',[1:1:14]);
set(gca,'XTickLabel',{'1','2','3','4','5', '6', '7','8', '9', '10', '11', '12', '13', '14'}, 'FontSize', 16);
set(gca,'YTick',0:0.1:0.5);
set(gca,'YTickLabel',{'0.0', '0.1','0.2', '0.3','0.4', '0.5'}, 'FontSize', 16);
set(gcf, 'PaperPositionMode', 'auto')

%% Dynamic Time Warping Algorithm
% t is the vector 
% r is the vector 
% D is the accumulated distance matrix
% Dist is unnormalized distance between t and r
% k is the normalizing factor (warping path).

%% step 1

[rows,N]=size(t);
[rows,M]=size(r);
for n=1:N
    for m=1:M
        d(n,m)= (t(n)-r(m))^2; % pdist2(t(n), r(m), 'euclidean'); %
    end
end

%% step 2
D=zeros(size(d));
D(1,1) = d(1,1);

for n=2:N
    D(n,1)=d(n,1)+D(n-1,1);
end

for m=2:M
    D(1,m)=d(1,m)+D(1,m-1);
end

for n=2:N
    for m=2:M
        D(n,m)=d(n,m)+min([D(n-1,m),D(n-1,m-1),D(n,m-1)]);
    end
end
D
Dist=D(N,M);


%% step 3
n=N;
m=M;
k=1;
w=[];
w(1,:)=[N,M];
while ((n+m)~=2)
    if (n-1)==0
        m=m-1;
    elseif (m-1)==0
        n=n-1;
    else 
      [values,number]=min([D(n-1,m),D(n,m-1),D(n-1,m-1)]);
      switch number
      case 1
        n=n-1;
      case 2
        m=m-1;
      case 3
        n=n-1;
        m=m-1;
      end
  end
    k=k+1;
     w=cat(1,w,[n,m]);
end

%% weighted distance :: return 
D_weighted = Dist/(k);

end

